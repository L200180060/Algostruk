#No 2
def PersegiEmpat(x, y):
    print ('@'*y)
    for i in range(x-2):
        print ('@'+' '*(y-2)+'@')
    print ('@'*y)
